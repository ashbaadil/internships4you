<?php
// DB Params
define("DB_HOST", "localhost");
define("DB_USER", "ashba");
define("DB_PASS", "insert_passHERE");
define("DB_NAME", "Internships4You");

define("SITE_TITLE", "Internships4You");