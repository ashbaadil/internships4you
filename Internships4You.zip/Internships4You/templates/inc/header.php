<!DOCTYPE html>
<html>
<head>
	<title>
	    
	    
	    Internships4You</title>
	

	<link rel="stylesheet" href="templates/bootstrap.css">
	<link rel="stylesheet" href="css/styles.css">
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="./style.css" />
</head>
<body>
    <div class="container">
   <div class="header clearfix">
   
               
     <ul class="nav nav-pills pull-left" style="float: right;">
   
             
            <li role="presentation" style="margin-right: 10px;"><a href="index.php">Home</a></li>
            <li role="presentation"><a href="create.php">Create Listing</a></li>
            
            
            
          </ul>
    
        <h3 class="text-muted" style="float: left;"><?php echo SITE_TITLE; ?></h3>
        
        <div style="clear: both;"></div>
        
      </div>