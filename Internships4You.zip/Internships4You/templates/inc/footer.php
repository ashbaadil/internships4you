			<footer class="footer">
        <p>&copy; 2020 Internships4You.</p>
      </footer>

    </div> <!-- /container -->
		</body>
</html>